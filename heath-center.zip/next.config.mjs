/** @type {import('next').NextConfig} */
const nextConfig = {
  // 디버그 모드 셋팅 활성화
  //   reactStrictMode: true,
};

export default nextConfig;
